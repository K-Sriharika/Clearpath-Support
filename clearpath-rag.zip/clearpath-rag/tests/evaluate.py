"""
evaluate.py — LLM-as-a-judge evaluation for the Clearpath RAG agent.

Evaluation design
-----------------
We run 10 test queries (5 in-scope, 3 boundary/tricky, 2 out-of-scope) through
the agent, then send each (question, answer, retrieved_context) triple to a
judge model with a structured rubric.  The judge scores on four dimensions:

  1. Groundedness (0–3): Is every claim in the answer traceable to the context?
     0 = answer contains facts not in context (hallucination)
     1 = mostly grounded, one minor unsupported inference
     2 = fully grounded with minor paraphrase
     3 = fully grounded and precise

  2. Correctness (0–3): Is the answer factually accurate given the KB?
     0 = contains an error
     1 = partially correct
     2 = correct but incomplete
     3 = correct and complete

  3. Fallback quality (0–2): Only scored when agent returned a fallback.
     0 = no fallback when one was needed, or unhelpful fallback
     1 = fallback triggered correctly, somewhat helpful
     2 = fallback triggered correctly, clearly helpful with next steps

  4. Conciseness (0–2): Is the answer appropriately brief?
     0 = bloated / off-topic padding
     1 = acceptable length
     2 = tight and direct

Max score: 10 for answered queries (3+3+2+2), 4 for fallback queries (2+2).

Judge model: claude-haiku-4-5 (same tier as agent — cost-symmetric; using a
larger judge would inflate costs without materially improving rubric scoring
on a structured 0-3 scale).

Cost note: 10 judge calls × ~700 tokens in / ~200 tokens out ≈ $0.02 total.
"""

from __future__ import annotations

import json
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import anthropic

# Allow imports from src/ when running from project root
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from chunker import load_chunks
from embedder import build_index
from agent import answer as agent_answer, AgentResponse

# ---------------------------------------------------------------------------
# Test suite
# ---------------------------------------------------------------------------

@dataclass
class TestCase:
    id: str
    query: str
    category: str          # "in_scope" | "boundary" | "out_of_scope"
    expected_fallback: bool
    notes: str             # what the ideal answer should cover


TEST_CASES: List[TestCase] = [
    # --- In-scope: direct FAQ matches ---
    TestCase(
        id="TC01",
        query="How do I invite a teammate to my workspace?",
        category="in_scope",
        expected_fallback=False,
        notes="Should mention Settings > Team > Invite Member, email, role selection, 48-hour link validity.",
    ),
    TestCase(
        id="TC02",
        query="Why are my CSAT scores not showing up?",
        category="in_scope",
        expected_fallback=False,
        notes="24-hour refresh cycle, CSAT trigger setting, minimum 5 responses required.",
    ),
    TestCase(
        id="TC03",
        query="My webhook stopped firing — what should I check?",
        category="in_scope",
        expected_fallback=False,
        notes="Runbook steps: URL reachable, event type selected, delivery log, retry logic from v2.3.5.",
    ),
    # --- In-scope: requires cross-document synthesis ---
    TestCase(
        id="TC04",
        query="Can I export more than 30 days of ticket data?",
        category="in_scope",
        expected_fallback=False,
        notes="Yes — limit raised to 90 days in v2.3.5. Should mention both FAQ (90-day max) and release note.",
    ),
    TestCase(
        id="TC05",
        query="Tickets aren't going to the right team. What could be wrong?",
        category="in_scope",
        expected_fallback=False,
        notes="Runbook steps: Labels vs Tags distinction, routing rule existence, active agents, rule priority order.",
    ),
    # --- Boundary: partially overlapping ---
    TestCase(
        id="TC06",
        query="How do I enable AI reply suggestions for my agents?",
        category="boundary",
        expected_fallback=False,
        notes="Opt-in under Settings > AI Features (v2.3.0). Pro plan required. Should not mention anything beyond KB.",
    ),
    TestCase(
        id="TC07",
        query="What roles can I assign when inviting a new user?",
        category="boundary",
        expected_fallback=False,
        notes="FAQ: Admin, Agent, Viewer. Release v2.3.0 added Custom roles — ideal answer synthesises both.",
    ),
    TestCase(
        id="TC08",
        query="An agent says they never received the export email. Walk me through debugging.",
        category="boundary",
        expected_fallback=False,
        notes="Runbook: spam folder, verified email, >90 days silently fails. Should be step-by-step.",
    ),
    # --- Out-of-scope: should trigger fallback ---
    TestCase(
        id="TC09",
        query="What is the best CRM to integrate with Clearpath?",
        category="out_of_scope",
        expected_fallback=True,
        notes="No CRM integration content in KB. Fallback required.",
    ),
    TestCase(
        id="TC10",
        query="How do I configure SAML SSO with Okta?",
        category="out_of_scope",
        expected_fallback=True,
        notes="KB only mentions SSO in passing (IdP metadata check). No Okta-specific content. Fallback required.",
    ),
]

# ---------------------------------------------------------------------------
# Judge prompt
# ---------------------------------------------------------------------------

JUDGE_SYSTEM = """\
You are an expert QA evaluator for a customer-support AI system.
You will be given a QUESTION, the RETRIEVED CONTEXT the agent had access to,
and the AGENT ANSWER.  Score the answer using the rubric below.
Return ONLY valid JSON matching the schema — no extra text.

RUBRIC:
{
  "groundedness": <int 0-3>,   // 0=hallucination present, 3=fully grounded in context
  "correctness":  <int 0-3>,   // 0=factual error, 3=correct and complete vs KB
  "fallback_quality": <int 0-2 | null>,  // null if agent gave a full answer; 0-2 if fallback
  "conciseness":  <int 0-2>,   // 0=padded/off-topic, 2=tight and direct
  "reasoning":    "<one or two sentences explaining your scores>"
}

SCORING GUIDELINES:
groundedness:
  3 — Every factual claim maps to a specific passage in the context.
  2 — All claims grounded; minor rephrasing that could be misread.
  1 — Most claims grounded; one inference not explicitly in context.
  0 — At least one claim contradicts or is absent from the context.

correctness:
  3 — Answer is accurate and covers all material points the context supports.
  2 — Accurate but omits a meaningful detail (e.g. missing a prerequisite step).
  1 — Partially correct; one factual error or significant omission.
  0 — Contains a factual error relative to the context.

fallback_quality (only when the agent response is a fallback/escalation message):
  2 — Correctly triggered; response is helpful with actionable next steps.
  1 — Correctly triggered but response is generic or minimally helpful.
  0 — Fallback triggered when a good answer was available, OR not triggered when it should have been.
  null — Agent gave a substantive answer (not a fallback).

conciseness:
  2 — Tight, direct, no filler.
  1 — Acceptable; minor verbosity.
  0 — Padded, repetitive, or off-topic sections.
""".strip()


def _judge_prompt(tc: TestCase, resp: AgentResponse) -> str:
    ctx_texts = [
        f"[{chunk.source} / {chunk.section_hint}]:\n{chunk.text}"
        for _, chunk in resp.retrieved_chunks
    ]
    context_block = "\n\n".join(ctx_texts) if ctx_texts else "(no chunks retrieved)"
    return (
        f"QUESTION: {tc.query}\n\n"
        f"RETRIEVED CONTEXT:\n{context_block}\n\n"
        f"AGENT ANSWER:\n{resp.answer}\n\n"
        f"Is this a fallback response? {'YES' if resp.is_fallback else 'NO'}\n\n"
        "Score the answer using the rubric and return JSON only."
    )


# ---------------------------------------------------------------------------
# Result dataclasses
# ---------------------------------------------------------------------------

@dataclass
class JudgeScore:
    groundedness: int
    correctness: int
    fallback_quality: Optional[int]
    conciseness: int
    reasoning: str

    @property
    def total(self) -> int:
        base = self.groundedness + self.correctness + self.conciseness
        if self.fallback_quality is not None:
            base += self.fallback_quality
        return base

    @property
    def max_possible(self) -> int:
        return 10 if self.fallback_quality is None else 4


@dataclass
class EvalResult:
    test_case: TestCase
    agent_response: AgentResponse
    judge_score: JudgeScore
    judge_input_tokens: int
    judge_output_tokens: int


# ---------------------------------------------------------------------------
# Run evaluation
# ---------------------------------------------------------------------------

def run_evaluation(
    kb_dir: str | Path = "../knowledge_base",
    output_path: str | Path = "../eval/eval_results.json",
    judge_model: str = "claude-haiku-4-5",
) -> List[EvalResult]:
    """
    Run all TEST_CASES through the agent then score each with the judge.
    Saves results to *output_path* as JSON.
    """
    kb_dir = Path(kb_dir)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    client = anthropic.Anthropic()

    print("=== Building KB index ===")
    chunks = load_chunks(kb_dir)
    index = build_index(chunks)

    results: List[EvalResult] = []
    total_agent_in = total_agent_out = 0
    total_judge_in = total_judge_out = 0

    print(f"\n=== Running {len(TEST_CASES)} test cases ===\n")

    for tc in TEST_CASES:
        print(f"[{tc.id}] {tc.query[:60]}…")

        # --- Agent call ---
        resp = agent_answer(tc.query, index, client)
        total_agent_in += resp.input_tokens
        total_agent_out += resp.output_tokens

        status = "FALLBACK" if resp.is_fallback else f"ANSWER (conf={resp.confidence:.3f})"
        print(f"       Agent: {status}")

        # --- Judge call ---
        judge_user = _judge_prompt(tc, resp)
        judge_resp = client.messages.create(
            model=judge_model,
            max_tokens=300,
            system=JUDGE_SYSTEM,
            messages=[{"role": "user", "content": judge_user}],
        )
        total_judge_in += judge_resp.usage.input_tokens
        total_judge_out += judge_resp.usage.output_tokens

        raw_json = judge_resp.content[0].text.strip()
        # Strip markdown fences if the model wrapped in them
        if raw_json.startswith("```"):
            raw_json = raw_json.split("```")[1]
            if raw_json.startswith("json"):
                raw_json = raw_json[4:]
        try:
            scores = json.loads(raw_json)
        except json.JSONDecodeError as e:
            print(f"  !! JSON parse error: {e}\n  Raw: {raw_json[:200]}")
            scores = {
                "groundedness": 0, "correctness": 0,
                "fallback_quality": None, "conciseness": 0,
                "reasoning": "parse error"
            }

        judge_score = JudgeScore(
            groundedness=scores.get("groundedness", 0),
            correctness=scores.get("correctness", 0),
            fallback_quality=scores.get("fallback_quality"),
            conciseness=scores.get("conciseness", 0),
            reasoning=scores.get("reasoning", ""),
        )
        print(f"       Judge: {judge_score.total}/{judge_score.max_possible} — {judge_score.reasoning[:80]}")

        results.append(EvalResult(
            test_case=tc,
            agent_response=resp,
            judge_score=judge_score,
            judge_input_tokens=judge_resp.usage.input_tokens,
            judge_output_tokens=judge_resp.usage.output_tokens,
        ))

        time.sleep(0.3)   # gentle rate-limit buffer

    # --- Summary ---
    in_scope = [r for r in results if r.test_case.category == "in_scope"]
    boundary = [r for r in results if r.test_case.category == "boundary"]
    oos = [r for r in results if r.test_case.category == "out_of_scope"]

    def avg_score(subset):
        if not subset:
            return 0
        return sum(r.judge_score.total for r in subset) / sum(r.judge_score.max_possible for r in subset)

    print("\n=== EVALUATION SUMMARY ===")
    print(f"  In-scope    ({len(in_scope)} cases): avg {avg_score(in_scope)*100:.0f}%")
    print(f"  Boundary    ({len(boundary)} cases): avg {avg_score(boundary)*100:.0f}%")
    print(f"  Out-of-scope({len(oos)} cases): avg {avg_score(oos)*100:.0f}%")
    overall = avg_score(results)
    print(f"  Overall     ({len(results)} cases): avg {overall*100:.0f}%")
    print(f"\n  Token usage — Agent:  {total_agent_in} in / {total_agent_out} out")
    print(f"               Judge:  {total_judge_in} in / {total_judge_out} out")

    # --- Serialise results ---
    serialisable = []
    for r in results:
        serialisable.append({
            "id": r.test_case.id,
            "query": r.test_case.query,
            "category": r.test_case.category,
            "expected_fallback": r.test_case.expected_fallback,
            "notes": r.test_case.notes,
            "agent_answer": r.agent_response.answer,
            "agent_confidence": round(r.agent_response.confidence, 4),
            "agent_is_fallback": r.agent_response.is_fallback,
            "agent_model": r.agent_response.model_used,
            "agent_tokens_in": r.agent_response.input_tokens,
            "agent_tokens_out": r.agent_response.output_tokens,
            "retrieved_chunks": [
                {
                    "score": round(score, 4),
                    "source": chunk.source,
                    "chunk_index": chunk.chunk_index,
                    "section_hint": chunk.section_hint,
                    "text_preview": chunk.text[:120],
                }
                for score, chunk in r.agent_response.retrieved_chunks
            ],
            "judge_groundedness": r.judge_score.groundedness,
            "judge_correctness": r.judge_score.correctness,
            "judge_fallback_quality": r.judge_score.fallback_quality,
            "judge_conciseness": r.judge_score.conciseness,
            "judge_total": r.judge_score.total,
            "judge_max": r.judge_score.max_possible,
            "judge_pct": round(r.judge_score.total / r.judge_score.max_possible * 100, 1),
            "judge_reasoning": r.judge_score.reasoning,
            "judge_tokens_in": r.judge_input_tokens,
            "judge_tokens_out": r.judge_output_tokens,
        })

    with open(output_path, "w") as f:
        json.dump({"results": serialisable, "summary": {
            "overall_pct": round(overall * 100, 1),
            "in_scope_pct": round(avg_score(in_scope) * 100, 1),
            "boundary_pct": round(avg_score(boundary) * 100, 1),
            "out_of_scope_pct": round(avg_score(oos) * 100, 1),
            "total_agent_tokens_in": total_agent_in,
            "total_agent_tokens_out": total_agent_out,
            "total_judge_tokens_in": total_judge_in,
            "total_judge_tokens_out": total_judge_out,
        }}, f, indent=2)

    print(f"\nResults saved to {output_path}")
    return results


if __name__ == "__main__":
    kb = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("../knowledge_base")
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("../eval/eval_results.json")
    run_evaluation(kb_dir=kb, output_path=out)
