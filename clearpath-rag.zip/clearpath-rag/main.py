"""
main.py — Entry point for the Clearpath RAG Support Agent.

Usage
-----
  # Interactive CLI
  python main.py

  # Single query
  python main.py --query "How do I invite a teammate?"

  # Run evaluation suite
  python main.py --evaluate

  # Custom KB path
  python main.py --kb-dir /path/to/knowledge_base --query "..."

Environment
-----------
  ANTHROPIC_API_KEY  Required. Set before running.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import anthropic

# Ensure src/ is on the import path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from chunker import load_chunks
from embedder import build_index
from agent import answer, CONFIDENCE_THRESHOLD


def build_pipeline(kb_dir: Path):
    """Load KB, build index, return (index, client)."""
    print(f"Loading knowledge base from: {kb_dir}")
    chunks = load_chunks(kb_dir)
    index = build_index(chunks)
    client = anthropic.Anthropic()
    return index, client


def interactive_loop(index, client):
    """Simple REPL for manual testing."""
    print("\nClearpath Support Agent — interactive mode")
    print(f"Confidence threshold: {CONFIDENCE_THRESHOLD}")
    print("Type 'quit' or Ctrl-C to exit.\n")

    while True:
        try:
            query = input("Question: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not query:
            continue
        if query.lower() in {"quit", "exit", "q"}:
            break

        resp = answer(query, index, client)
        tag = "[FALLBACK]" if resp.is_fallback else "[ANSWER]"
        print(f"\n{tag} (retrieval confidence: {resp.confidence:.4f})")
        print("-" * 60)
        print(resp.answer)
        print("-" * 60)

        if not resp.is_fallback:
            print(f"Sources used:")
            for score, chunk in resp.retrieved_chunks:
                print(f"  • {chunk.source} / {chunk.section_hint}  (score: {score:.4f})")
            print(f"Tokens: {resp.input_tokens} in / {resp.output_tokens} out")
        print()


def run_eval(kb_dir: Path, output_path: Path):
    """Run LLM-as-a-judge evaluation suite."""
    # Import here so evaluate.py's __main__ guard doesn't fire
    sys.path.insert(0, str(Path(__file__).parent / "tests"))
    from evaluate import run_evaluation
    run_evaluation(kb_dir=kb_dir, output_path=output_path)


def main():
    parser = argparse.ArgumentParser(description="Clearpath RAG Support Agent")
    parser.add_argument("--kb-dir", default="knowledge_base",
                        help="Path to knowledge base directory")
    parser.add_argument("--query", help="Single query to answer (non-interactive)")
    parser.add_argument("--evaluate", action="store_true",
                        help="Run LLM-as-a-judge evaluation suite")
    parser.add_argument("--eval-output", default="eval/eval_results.json",
                        help="Path for evaluation results JSON")
    args = parser.parse_args()

    kb_dir = Path(args.kb_dir)

    if args.evaluate:
        run_eval(kb_dir, Path(args.eval_output))
        return

    index, client = build_pipeline(kb_dir)

    if args.query:
        resp = answer(args.query, index, client)
        tag = "[FALLBACK]" if resp.is_fallback else "[ANSWER]"
        print(f"\n{tag} (confidence: {resp.confidence:.4f})\n")
        print(resp.answer)
        if not resp.is_fallback:
            print(f"\nTokens: {resp.input_tokens} in / {resp.output_tokens} out")
    else:
        interactive_loop(index, client)


if __name__ == "__main__":
    main()
